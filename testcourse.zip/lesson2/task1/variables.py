# Assign values to the 3 variables

name = enter your name
age = enter your age
likes_cake = do you like cake?

print("My name is " + name + ". I am " + str(age) + " years old. It is " + str(likes_cake) + " that I like cake")
