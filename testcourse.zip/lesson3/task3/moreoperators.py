
exponentiation =

modulo =