# TODO: type solution here

lyric1 = " bottles of beer on the wall. "
lyric2 = " bottles of beer. You take one down, pass it around, "
lyric3 = " bottle of beer on the wall. "
lyric4 = " bottle of beer. You take it down, pass it around, go to the store and buy some more!"

for i in range(99, 1, -1):
    if i > 2:
        print(str(i) + lyric1 + str(i) + lyric2 + str(i - 1) + lyric1)
    else:
        print(str(i) + lyric1 + str(i) + lyric2 + str(i - 1) + lyric3)
        print(str(i - 1) + lyric3 + str(i - 1) + lyric4)