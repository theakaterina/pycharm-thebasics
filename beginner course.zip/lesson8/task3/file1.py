
exponentiation = 1 ** 2

modulo = 5 % 2
