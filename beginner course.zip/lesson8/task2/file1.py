
# Print division with two integers
print(integers)

# Print same division using at least one float
print(floats)