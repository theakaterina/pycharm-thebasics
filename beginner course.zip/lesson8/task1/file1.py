# Make addition, subtraction, multiplication and division all equal 10 using the difference operators

addition =

subtraction =

multiplication =

division =

print(addition, subtraction, multiplication, division)
