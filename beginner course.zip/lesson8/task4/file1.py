import math

print math.factorial(6)