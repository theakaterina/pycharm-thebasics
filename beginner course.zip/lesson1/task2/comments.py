# This is a single line comment
# notahashtag

comment out these lines
or your code won't work :(

#print("and uncomment this one!")