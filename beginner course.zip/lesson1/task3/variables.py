# Assign values to the 3 variables

name =
age =
likes_cake =

print("My name is " + name + ". I am " + str(age) + " years old. It is " + str(likes_cake) + " that I like cake")
