adjective1 = raw_input("ADJECTIVE: ")
noun1 = raw_input("NOUN: ")
adjective2 = raw_input("ADJECTIVE: ")
verb_pt = raw_input("PAST TENSE VERB: ")
noun2 = raw_input("NOUN: ")


print("Once upon a time there was a {} {}. She was trapped in a {} tower, and decided to escape. "
      "She {} down the outside {} to freedom.").format(adjective1, noun1, adjective2, verb_pt, noun2)