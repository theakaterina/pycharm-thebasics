# Define a function "pythagorean_triple" that takes 3 arguments and tests whether or not they
# can form a right angled triangle


def pythagorean_triple(a, b, c):

    if a**2 + b**2 == c**2:
        return True
    elif a**2 + c**2 == b**2:
        return True
    elif b**2 + c**2 == a**2:
        return True
    else:
        return False

print pythagorean_triple(3, 4, 5)