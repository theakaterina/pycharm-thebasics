# Create a list of your favourite things here

favourite_things =

print favourite_things