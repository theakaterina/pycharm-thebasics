colours = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"]

# What will colours[2] return?
answer1 =

# What will colours[-2] return?
answer2 =

# What will len(colours) return?
answer3 =

# What will colours[0:3] return?
answer4 =

# How would I return every third colour, starting at red?
answer5 =