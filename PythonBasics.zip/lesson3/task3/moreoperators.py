# Exponentiation is **
exponentiation =

# Modulo is %. We want a remainder of 8
modulo =

print exponentiation, modulo