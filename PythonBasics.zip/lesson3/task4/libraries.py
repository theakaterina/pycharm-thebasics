import math

# Radius of the circle
r =

# Area of the circle
area =

print area