# Assign values to the 3 variables

name = enter your name
age = enter your age
likes_cake = do you like cake?

# Notice how to print multiple things, we separate them by commas
print "My name is ", name, ". I am ", age, " years old. It is ", likes_cake, " that I like cake"
