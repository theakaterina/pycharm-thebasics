
# Print division with two integers
print

# Print the same division using at least one float
print