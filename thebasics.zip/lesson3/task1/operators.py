# Make addition, subtraction, multiplication and division all equal 10 using the different operators

addition =

subtraction =

multiplication =

division =

print addition, subtraction, multiplication, division
