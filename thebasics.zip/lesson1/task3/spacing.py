# This program finds all sum of all multiples of 3 or 5 below 1000
# Fix the indents so that it will run

    answer = 0
for i in range(0, 1000):
if i % 3 == 0 or i % 5 == 0:
        answer += i
            i += 1
    else:
    i += 1

print answer