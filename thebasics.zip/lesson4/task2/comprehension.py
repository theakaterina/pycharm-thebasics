# L is a list of the numbers 1 - 10
L = range(11)

# Define doubles here
doubles =

print doubles