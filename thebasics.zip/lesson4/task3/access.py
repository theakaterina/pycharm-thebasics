colours = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"]

# What will colours[2] return?
answer1 = what colour?

# What will colours[-2] return?
answer2 = what colour?

# What will len(colours) return?
answer3 = length

# What will colours[0:3] return?
answer4 = which colours?

# How would I return every third colour, starting at red?
answer5 = list[start:stop:step]